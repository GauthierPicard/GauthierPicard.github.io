/****************************************/
% NOM : 
% PRENOM :

/* load the three search algorithms */
:- ensure_loaded('astar.pl').
:- ensure_loaded('astarCC.pl').
:- ensure_loaded('idastar.pl').

% -------------------------------------------------------------------------------------------------------------
%   Question 1, Part a
% -------------------------------------------------------------------------------------------------------------

/* init( +Name, -State)

   State is the initial state for problem Name
*/



%  -------------------------------------------------------------------------------------------------------------
%   Question 1, Part b
%  -------------------------------------------------------------------------------------------------------------

/* goal( +State )

   holds if and oly if State is a goal state
*/


%  -------------------------------------------------------------------------------------------------------------
%   Question 1, Part c
%  -------------------------------------------------------------------------------------------------------------

/* successors( +State, -Neighbors)

   Neighbors is a list of elements (Cost, NewState) where
   NewState is a state reachable from State by one action and
   Cost is the cost for that corresponding action (=1 in our
   case)
*/


%   -----------------------------------------------------------------------------------------------------------------
%   Question 1, Part d
%   -----------------------------------------------------------------------------------------------------------------


/* equality(+S1, +S2)

   holds if and only S1 and S2 describe the same state
*/






%   -----------------------------------------------------------------------------------------------------------------
%   Question 1, Part e
%   -----------------------------------------------------------------------------------------------------------------



/* hfn_null( +State, -V)

   V is the null heuristic for State (=0 irrelevant of the state)
*/

hfn_null(_State, 0).






/* hfn_euclidean(+State, -V)

V is the  ..................

*/
% hfn_euclidean( State, V) :-  ...





/* hfn_manhattan( +State, -V)

   V is the ..............................
*/
% hfn_manhattan( State, V ) :-  ...




/* hfn_diagonal( +State, -V)

   V is the ..............................
*/
% hfn_diagonal( State, V ) :-  ...





%   -----------------------------------------------------------------------------------------------------------------
%   Calling the search algorithms
%   -----------------------------------------------------------------------------------------------------------------

go(ProblemName, HFN) :-
	init(ProblemName, Init),
	astar(Init, successors, goal, HFN, Path, equality),
	writeln(Path).

goCC(ProblemName, HFN) :-
	init(ProblemName, Init),
	astarCC(Init, successors, goal, HFN, Path, equality),
	writeln(Path).

goIDA(ProblemName, HFN) :-
	init(ProblemName, Init),
	idastar(Init, successors, goal, HFN, Path, equality),
	writeln(Path).

