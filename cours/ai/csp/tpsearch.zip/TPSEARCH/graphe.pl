/****************************************/
% NOM : 
% PRENOM :

initial(a).

final(h).

% Définir le prédicat s/2.

% Prédicat successeur/3
successeur(X,Y,Op) :- s(X,Y), atom_concat(X,' to ',T), atom_concat(T,Y,Op).
successeur(X,Y,Op) :- s(Y,X), atom_concat(Y,' to ',T), atom_concat(T,X,Op).
