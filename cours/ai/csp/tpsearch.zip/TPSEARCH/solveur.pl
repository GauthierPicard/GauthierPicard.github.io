/****************************************/
% NOM : 
% PRENOM :

/***************************************/
/* profondeur sur arbre                */
% A ECRIRE

go1 :-
	initial(I),
	solve1(I,P),
	ecrire(P).

% ecrire le prédicat solve1/2

/***************************************/
/* profondeur sans cycle               */
% A ECRIRE

go2 :-
	initial(I),
	solve2([I],I,P),
	ecrire(P).

% ecrire le prédicat solve2/2

/***************************************/
/* largeur sur graphe                 */

go3 :-
	initial(I),
	solve3([],[[I]],S),
	reverse(S,RevS),
	length(S,X),
	write(X),nl,
	ecrire(RevS).

solve3([],Frontiere,S) :-
	final(F),
	membre(F,Frontiere,S).

solve3([],Frontiere,S) :-
	\+ Frontiere=[],
	solve3(Frontiere,[],S).

solve3([[T|Q]|Adevelopper],Frontiere,S) :-
	findall([Y,T|Q],(successeur(T,Y,_),\+ member(Y,[T|Q])),Ls),
	append(Ls,Frontiere,NewFrontiere),
	solve3(Adevelopper,NewFrontiere,S).

/***************************************/

membre(X,[[X|Q]|_],[X|Q]).

membre(X,[_|L],Y) :-
	membre(X,L,Y).

/***************************************/

ecrire([DernierEtat]) :-
        write(DernierEtat), nl,
	write('mission accomplie'),
	nl,
	nl.

ecrire([T,Suiv|Q]):-
	successeur(T,Suiv,Op),
        write(T),
	nl,
        write('--> '), write(Op),write('-->'), nl,
        append([Suiv],Q,S),
	ecrire(S).
